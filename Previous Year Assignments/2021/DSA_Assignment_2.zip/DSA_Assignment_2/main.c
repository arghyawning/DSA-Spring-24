#include "utils.h"

int main(){
    // test_bstsort();

    // test_finddepth();

    // test_height();

    test_isbst();

    // test_inRange();

    return 0;
}
